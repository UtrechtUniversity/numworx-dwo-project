/**
 * Copyrighted Sep 24, 2015
 */
package nl.uu.fi.dwo.rest.entities;

import nl.uu.fi.dwo.rest.dom.entities.DomContext;
import nl.uu.fi.dwo.rest.dom.entities.DomStudent;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * @author G.A.J. van der Plas
 */

@XmlRootElement
public class RestStudent {
    private DomContext restContext;
    private DomStudent domStudent;

    public RestStudent() {
        super();
    }

//    
//    public RestStudent(PersistentUser u) {
//        super(u);
//    }

    /**
     * @return the restContext
     */
    public DomContext getRestContext() {
        return restContext;
    }

    /**
     * @param restContext the restContext to set
     */
    public void setRestContext(DomContext restContext) {
        this.restContext = restContext;
    }

    /**
     * @return the domUser
     */
    public DomStudent getDomStudent() {
        return domStudent;
    }

    /**
     * @param domStudent
     */
    public void setDomStudent(DomStudent domStudent) {
        this.domStudent = domStudent;
    }
}
